<?php
/**
 * Cobalt by MintJoomla (http://www.mintjoomla.com)
 * a component for Joomla! 1.7 - 3.1 CMS (http://www.joomla.org)
 * Author: Pavel Ivanov
 * Author Website: http://www.cobalt-cck.ru/
 * @copyright Copyright (C) 2013 Сobalt by Russian (http://www.cobalt-cck.ru/). All rights reserved.
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die();
require_once JPATH_ROOT. DIRECTORY_SEPARATOR .'components/com_cobalt/library/php/fields/cobaltfield.php';

class JFormFieldCSimpletext_base extends CFormField
{
//********************************
	public function getInput()
	{
		return $this->_display_input();
	}
//********************************
	public function onPrepareSave($value, $record, $type, $section)
	{
		return $value;
	}
//********************************
	public function onRenderList($record, $type, $section)
	{
		return $this->_display_output('list', $record, $type, $section);
	}
//********************************	
	public function onRenderFull($record, $type, $section)
	{
		return $this->_display_output('full', $record, $type, $section);
	}
//********************************	
	public function onPrepareFullTextSearch($value, $record, $type, $section)
	{
		return $this->onPrepareSave($value, $record, $type, $section);
	}
//********************************
}
