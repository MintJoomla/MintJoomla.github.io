<?php
/**
 * Cobalt by MintJoomla (http://www.mintjoomla.com)
 * a component for Joomla! 1.7 - 3.1 CMS (http://www.joomla.org)
 * Author: Pavel Ivanov
 * Author Website: http://www.cobalt-cck.ru/
 * @copyright Copyright (C) 2013 Сobalt by Russian (http://www.cobalt-cck.ru/). All rights reserved.
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */
defined('_JEXEC') or die();
?>

<?php echo $this->value;?>